from rest_framework import generics, filters
from .models import Product, ProductCategory
from .serializers import ProductSerializer, ProductCategorySerializer


from django_filters.rest_framework import DjangoFilterBackend
from .filters import ProductFilter


class ProductListAPIView(generics.ListAPIView):
    queryset = Product.objects.select_related('category').prefetch_related('variants', 'images')
    serializer_class = ProductSerializer


class ProductDetailAPIView(generics.RetrieveAPIView):
    queryset = Product.objects.select_related('category').prefetch_related('variants', 'images')
    serializer_class = ProductSerializer
    lookup_field = 'slug'


class CategoryListAPIView(generics.ListAPIView):
    queryset = ProductCategory.objects.filter(is_active=True)
    serializer_class = ProductCategorySerializer


class ProductFilterAPIView(generics.ListAPIView):
    serializer_class = ProductSerializer
    filter_backends = [
        DjangoFilterBackend,
        filters.SearchFilter,
        filters.OrderingFilter,
    ]
    filterset_class = ProductFilter
    search_fields = ['name']
    ordering_fields = ['price', 'created_at']
    ordering = ['-created_at']

    def get_queryset(self):
        return (
            Product.objects
            .select_related('category')
            .prefetch_related('variants', 'images')
            .all()
        )
