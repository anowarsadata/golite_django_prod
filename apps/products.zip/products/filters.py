import django_filters
from .models import Product


class ProductFilter(django_filters.FilterSet):
    category = django_filters.CharFilter(
        field_name='category__slug',
        lookup_expr='iexact'
    )

    min_price = django_filters.NumberFilter(
        field_name='price',
        lookup_expr='gte'
    )

    max_price = django_filters.NumberFilter(
        field_name='price',
        lookup_expr='lte'
    )

    in_stock = django_filters.BooleanFilter(method='filter_in_stock')
    variant_attribute = django_filters.CharFilter(method='filter_variant_attribute')

    class Meta:
        model = Product
        fields = []

    def filter_in_stock(self, queryset, name, value):
        if value:
            return queryset.filter(variants__stock__gt=0).distinct()
        return queryset

    def filter_variant_attribute(self, queryset, name, value):
        """
        SQLite-safe filtering
        Example:
        ?variant_attribute=color:red
        """
        try:
            key, val = value.split(':')
        except ValueError:
            return queryset

        matched_product_ids = set()

        for product in queryset.prefetch_related('variants'):
            for variant in product.variants.all():
                attrs = variant.attributes or {}
                if str(attrs.get(key)).lower() == val.lower():
                    matched_product_ids.add(product.id)

        return queryset.filter(id__in=matched_product_ids)
